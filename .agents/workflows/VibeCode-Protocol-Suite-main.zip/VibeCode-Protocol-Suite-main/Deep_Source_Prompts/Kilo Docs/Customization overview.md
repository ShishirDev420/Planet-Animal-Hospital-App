---
title: "Customize"
description: "Make Kilo Code work your way with custom modes, rules, instructions, and more"
---

# {% $markdoc.frontmatter.title %}

{% callout type="generic" %}
Kilo Code is highly customizable. Tailor its behavior to match your workflow, team standards, and project requirements with custom modes, rules, instructions, and more.
{% /callout %}

## Customization

Configure how Kilo Code behaves and responds:

- [**Custom Modes**](/docs/customize/custom-modes) — Create specialized modes for different tasks (code review, documentation, testing, etc.)
- [**Custom Rules**](/docs/customize/custom-rules) — Define rules that apply to specific file types or situations
- [**Custom Instructions**](/docs/customize/custom-instructions) — Add project-specific guidelines and context
- [**agents.md**](/docs/customize/agents-md) — Configure agent behavior at the project level
- [**Workflows**](/docs/customize/workflows) — Automate multi-step processes
- [**Skills**](/docs/customize/skills) — Extend Kilo's capabilities with reusable skill definitions
- [**Prompt Engineering**](/docs/customize/prompt-engineering) — Write effective prompts for better results

## Context & Indexing

Help Kilo understand your codebase better:

- [**Codebase Indexing**](/docs/customize/context/codebase-indexing) — Build a semantic index of your code for better context awareness
- [**Memory Bank**](/docs/customize/context/memory-bank) — Store project context, decisions, and important information
- [**Large Projects**](/docs/customize/context/large-projects) — Best practices for working with monorepos and large codebases

## Getting Started

New to customization? Here's where to start:

1. **Start with Custom Instructions** — Add a simple `.kilocode/instructions.md` file to your project
2. **Explore Custom Modes** — Try the built-in modes first, then create your own
3. **Enable Codebase Indexing** — Help Kilo understand your project structure

## Best Practices

- Keep custom instructions concise and actionable
- Use custom modes for repetitive tasks
- Combine rules with modes for powerful workflows
- Regularly update your memory bank with important decisions

## Next Steps

- Check out [**Code with AI**](/docs/code-with-ai) to learn how to use Kilo effectively
- Explore [**Automate**](/docs/automate) for CI/CD integration and advanced automation
- Learn about [**Collaboration**](/docs/collaborate) features for teams
