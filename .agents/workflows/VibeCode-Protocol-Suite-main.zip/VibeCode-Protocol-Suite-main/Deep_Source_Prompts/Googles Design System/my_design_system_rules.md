# My Design System: The Definitive Rulebook

This document is the **single source of truth** for the visual and interactive design of all products, regardless of the target platform (Web, Android, iOS, or otherwise). All design and engineering efforts MUST adhere to these rules without deviation. This is not a set of guidelines; it is a set of mandates.

Platform-specific implementations (Android XML Themes, Web CSS Custom Properties, iOS Schemes) are considered translation layers. Their sole purpose is to map native platform capabilities to the abstract tokens defined herein.

## 1. Core Theming Contract

All platforms MUST implement a centralized theming mechanism. This mechanism, hereafter referred to as the "Theme," is a container for all design tokens: Color, Typography, Shape, and Spacing. Components MUST source their styling from this Theme and NEVER use hard-coded values.

## 2. Typography System (The Canon)

This is the ONLY approved type scale. All text elements in the user interface MUST be styled using one of the following roles. Font sizes are defined canonically in pixels (`px`) and MUST be translated to the appropriate platform-specific density-independent unit (`sp` for Android, `rem` for Web, `pt` for iOS). `16px = 16sp = 1rem = 16pt`.

| Role | Font Size (Canonical) | Font Weight | Line Height | Letter Spacing |
| :--- | :--- | :--- | :--- | :--- |
| **Display Large** | 57px | Regular (400) | 64px | -0.25px |
| **Display Medium** | 45px | Regular (400) | 52px | 0px |
| **Display Small** | 36px | Regular (400) | 44px | 0px |
| **Headline Large** | 32px | Regular (400) | 40px | 0px |
| **Headline Medium** | 28px | Regular (400) | 36px | 0px |
| **Headline Small** | 24px | Regular (400) | 32px | 0px |
| **Title Large** | 22px | Regular (400) | 28px | 0px |
| **Title Medium** | 16px | Medium (500) | 24px | +0.15px |
| **Title Small** | 14px | Medium (500) | 20px | +0.1px |
| **Body Large** | 16px | Regular (400) | 24px | +0.5px |
| **Body Medium** | 14px | Regular (400) | 20px | +0.25px |
| **Body Small** | 12px | Regular (400) | 16px | +0.4px |
| **Label Large** | 14px | Medium (500) | 20px | +0.1px |
| **Label Medium** | 12px | Medium (500) | 16px | +0.5px |
| **Label Small** | 11px | Medium (500) | 16px | +0.5px |

### Font Families

-   **Brand Font**: The system's default sans-serif font. Used for Display and Headline styles.
-   **Plain Font**: The system's default sans-serif font. Used for Title, Body, and Label styles.
-   **Weights**: `Regular` maps to `400`. `Medium` maps to `500`.

## 3. Color System (The Palette)

All colors used in the UI MUST be drawn from the following semantic roles. No other colors are permitted. These roles are defined for both light and dark themes.

### Platform Token Naming Convention
-   **Android**: `colorPrimary`, `colorOnPrimary`
-   **Web**: `--md-sys-color-primary`, `--md-sys-color-on-primary`
-   **iOS**: `primaryColor`, `onPrimaryColor`
-   **Canonical**: `color-primary`, `color-on-primary`

---

### Default Light Theme Palette

| Canonical Token Name | Hex Value | Description |
| :--- | :--- | :--- |
| `color-primary` | `#6750A4` | Key interactive elements |
| `color-on-primary` | `#FFFFFF` | Content on `color-primary` |
| `color-primary-container` | `#EADDFF` | Less prominent primary elements |
| `color-on-primary-container`| `#21005D` | Content on `color-primary-container` |
| `color-secondary` | `#625B71` | Secondary interactive elements |
| `color-on-secondary` | `#FFFFFF` | Content on `color-secondary` |
| `color-secondary-container`| `#E8DEF8` | Less prominent secondary elements |
| `color-on-secondary-container`|`#1D192B` | Content on `color-secondary-container`|
| `color-tertiary` | `#7D5260` | Tertiary, contrasting accents |
| `color-on-tertiary` | `#FFFFFF` | Content on `color-tertiary` |
| `color-tertiary-container`| `#FFD8E4` | Less prominent tertiary elements |
| `color-on-tertiary-container`|`#31111D` | Content on `color-tertiary-container`|
| `color-error` | `#BA1A1A` | Error states |
| `color-on-error` | `#FFFFFF` | Content on `color-error` |
| `color-error-container` | `#FFDAD6` | Less prominent error elements |
| `color-on-error-container`| `#410E0B` | Content on `color-error-container` |
| `color-surface` | `#FEF7FF` | Base for components like cards, sheets |
| `color-on-surface` | `#1D1B20` | Default content color |
| `color-surface-variant` | `#E7E0EC` | Variant surface for differentiation |
| `color-on-surface-variant`| `#49454F` | Content on `color-surface-variant` |
| `color-outline` | `#79747E` | Borders and dividers |
| `color-outline-variant` | `#CAC4D0` | Decorative dividers or outlines |
| `color-shadow` | `#000000` | Shadow color |
| `color-scrim` | `#000000` | Scrim overlay color |

---

### Default Dark Theme Palette

| Canonical Token Name | Hex Value | Description |
| :--- | :--- | :--- |
| `color-primary` | `#D0BCFF` | Key interactive elements |
| `color-on-primary` | `#381E72` | Content on `color-primary` |
| `color-primary-container` | `#4F378B` | Less prominent primary elements |
| `color-on-primary-container`| `#EADDFF` | Content on `color-primary-container` |
| `color-secondary` | `#CCC2DC` | Secondary interactive elements |
| `color-on-secondary` | `#332D41` | Content on `color-secondary` |
| `color-secondary-container`| `#4A4458` | Less prominent secondary elements |
| `color-on-secondary-container`|`#E8DEF8` | Content on `color-secondary-container`|
| `color-tertiary` | `#EFB8C8` | Tertiary, contrasting accents |
| `color-on-tertiary` | `#492532` | Content on `color-tertiary` |
| `color-tertiary-container`| `#633B48` | Less prominent tertiary elements |
| `color-on-tertiary-container`|`#FFD8E4` | Content on `color-tertiary-container`|
| `color-error` | `#FFB4AB` | Error states |
| `color-on-error` | `#690005` | Content on `color-error` |
| `color-error-container` | `#93000A` | Less prominent error elements |
| `color-on-error-container`| `#FFDAD6` | Content on `color-error-container` |
| `color-surface` | `#141218` | Base for components like cards, sheets |
| `color-on-surface` | `#E6E1E5` | Default content color |
| `color-surface-variant` | `#49454F` | Variant surface for differentiation |
| `color-on-surface-variant`| `#CAC4D0` | Content on `color-surface-variant` |
| `color-outline` | `#938F99` | Borders and dividers |
| `color-outline-variant` | `#49454F` | Decorative dividers or outlines |
| `color-shadow` | `#000000` | Shadow color |
| `color-scrim` | `#000000` | Scrim overlay color |

## 4. Shape System (The Geometry)

Component shapes are defined by their corner radius. All shapes MUST use a circular ("rounded") corner treatment.

| Canonical Name | Canonical Radius (dp/px/pt) | Primary Usage |
| :--- | :--- | :--- |
| `shape-corner-none` | 0 | Full-bleed elements |
| `shape-corner-extra-small` | 4 | Chips, small form elements |
| `shape-corner-small` | 8 | Smaller cards, text fields |
| `shape-corner-medium` | 12 | Standard cards, dialogs |
| `shape-corner-large` | 16 | Larger cards, sheets |
| `shape-corner-extra-large`| 28 | Navigation drawers, large sheets |
| `shape-corner-full` | 9999 | Buttons, pills, fully rounded elements |

## 5. Spacing & Layout (The Grid)

All spacing, padding, and margins MUST be a multiple of the base unit.

-   **Base Unit**: `4dp / 4px / 4pt`
-   **Standard Spacing Increments**:
    -   `x1`: 4 units
    -   `x2`: 8 units
    -   `x3`: 12 units
    -   `x4`: 16 units
    -   `x6`: 24 units
    -   `x8`: 32 units
-   **Minimum Touch Target**: All interactive elements MUST have a minimum touch target size of `48x48` dp/px/pt.

## 6. Component Token Mapping (The Implementation Mandates)

The following sections define the non-negotiable token mappings for core components. Any new component MUST have a similar mapping defined and approved.

### Component: Filled Button

-   **Description**: A high-emphasis button with a solid background fill.
-   **Typography**: MUST use `typescale-label-large`.
-   **Color (Enabled state)**:
    -   Container Background: `color-primary`
    -   Content (Text/Icon): `color-on-primary`
-   **Color (Disabled state)**:
    -   Container Background: `color-on-surface` with 12% opacity.
    -   Content (Text/Icon): `color-on-surface` with 38% opacity.
-   **Shape**: MUST use `shape-corner-full`.
-   **Spacing**:
    -   Height: Minimum 40 units.
    -   Padding (Horizontal): 24 units.
    -   Padding (Icon Present): 16 units leading, 24 units trailing. Icon gap is 8 units.
-   **Elevation**:
    -   Default State: 0dp shadow.
    -   Hovered/Focused State: 2dp shadow.
    -   Pressed State: 0dp shadow.

### Component: Outlined Card

-   **Description**: A medium-emphasis container for content, delineated by an outline.
-   **Typography**: Content within the card MUST use the appropriate typography roles (e.g., `typescale-title-medium`, `typescale-body-medium`).
-   **Color**:
    -   Container Background: `color-surface`.
    -   Content (Text/Icon): `color-on-surface`.
    -   Outline: `color-outline`.
-   **Shape**: MUST use `shape-corner-medium` (12 units).
-   **Spacing**:
    -   Internal Padding: 16 units on all sides.
    -   External Margin: 16 units, unless part of a collection.
-   **Elevation**: 0dp shadow in all states. The outline provides visual separation.